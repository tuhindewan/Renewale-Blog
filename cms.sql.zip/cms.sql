-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 13, 2017 at 09:49 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`) VALUES
(33, 'khanki'),
(39, 'chutmarani'),
(40, 'diya');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `date`, `name`, `username`, `post_id`, `email`, `website`, `image`, `comment`, `status`) VALUES
(7, 1234567890, 'Md. Saiduzzaman Tuhin', 'tuhincste', 8, 'tuhinsshadow@gmail.com', 'www.renwale.com', 'tuhin.jpg', 'this is desmo comment to see is working or not.if its working then all codes are working properly.if its not then fuck off man!!!', 'approve'),
(8, 987654321, 'noorjahan nishat', 'nishatbge', 8, 'babydollnishat@gmail.com', 'babydoll.com', 'profile.jpg', 'this is working properly.second demo comment testing......', 'approve'),
(17, 1489218641, 'Saiduzzaman tuhin', 'tuhindewan', 6, 'tuhinsshado@gmail.com', '', 'profile.jpg', 'hello', 'approve'),
(18, 1489218874, 'Saiduzzaman tuhin', 'tuhindewan', 6, 'tuhinsshado@gmail.com', '', 'profile.jpg', 'hey i am tuhin dewan', 'approve'),
(19, 0, 'kawsar ahmed', 'user', 41, 'kawsar@gmail.com', '', 'profile.jpg', 'Bootstrap is very helpful for beginers', 'approve'),
(20, 1489382106, 'Saiduzzaman tuhin', 'tuhindewan', 41, 'tuhinsshado@gmail.com', '', 'profile.jpg', 'Bootswatch is another kind of Bootstrap ', 'approve');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `image`) VALUES
(15, '295658_433523036736678_230657872_n.png'),
(17, '482664_545115838844119_344908964_n.jpg'),
(18, 'bike.jpg'),
(19, 'facebook.png'),
(20, 'favicon.jpg'),
(21, 'google-plus.png'),
(22, 'linkedin.png'),
(23, 'logo.jpg'),
(24, 'skype.jpg'),
(25, 'twitter.jpg'),
(26, 'unknown-profile.png'),
(27, 'youtube.jpg'),
(28, '15590311_2024669837759734_4725947378523285965_n.jpg'),
(29, 'IMG_7173.JPG'),
(30, 'how-to-get-started-with-laravel-e1404789165403.jpg'),
(31, 'laravel_framework-1.jpg'),
(32, 'AAEAAQAAAAAAAAh8AAAAJGJjMTVhOTY1LTFjZDctNDZlYy1hMzgyLTZmYjVmMGVkMWM5NA.png'),
(33, 'laravel-2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `author_image` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `post_data` text NOT NULL,
  `views` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `date`, `title`, `author`, `author_image`, `image`, `categories`, `tags`, `post_data`, `views`, `status`) VALUES
(41, 1489377155, 'How to create a website template using Bootstrap', 'tuhindewan', 'profile.jpg', 'laravel_framework-1.jpg', 'khanki', 'Laravel, PHP Framework, Bootstrap, Bootswatch', '<!DOCTYPE html>\r\n<html>\r\n<head>\r\n</head>\r\n<body>\r\n<p>Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.Bootstrap is good framework.<img style="display: block; margin-left: auto; margin-right: auto;" src="media/laravel_framework-1.jpg" alt="laravel_framework-1.jpg" width="700" height="250" /></p>\r\n</body>\r\n</html>', 7, 'publish');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `salt` varchar(255) NOT NULL DEFAULT '$2y$10$quickbrownfoxjumpsover',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`,`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `date`, `first_name`, `last_name`, `username`, `email`, `image`, `password`, `role`, `details`, `salt`) VALUES
(18, 1234567890, 'Kawsar', 'ahmed', 'ahmed', 'kaswar@gmail.com', 'DSC03298.JPG', '$2y$10$quickbrownfoxjumpsovee2VSTnwk0PVLbOzNueOwLxjyiDighUXq', 'author', 'hey>.!! I Am Kawsar', '$2y$10$quickbrownfoxjumpsover'),
(22, 1489141770, 'polash', 'khan', 'khan', 'khan@gmail.com', 'youtube.jpg', '$2y$10$quickbrownfoxjumpsoveeCsRZQ6wpKMWf1QmsRpF2s/bAxRJOSfK', 'author', '', '$2y$10$quickbrownfoxjumpsover'),
(24, 1489142311, 'Saiduzzaman', 'tuhin', 'tuhindewan', 'tuhinsshado@gmail.com', 'profile.jpg', '$2y$10$quickbrownfoxjumpsoveeob1NkAIqYlnDNd6AAwE0Nv1BMtRiD26', 'admin', '', '$2y$10$quickbrownfoxjumpsover'),
(25, 1489153767, 'fahad', 'alan', 'alan', 'alan@gmail.com', 'skype.jpg', '$2y$10$quickbrownfoxjumpsoveeas4Z06OoEMpcFmRNhQw7AzFa4.nYSbi', 'author', '', '$2y$10$quickbrownfoxjumpsover'),
(26, 1489387630, 'towhed', 'rone', 'rone', 'rone@gmail.com', '15590311_2024669837759734_4725947378523285965_n.jpg', '$2y$10$quickbrownfoxjumpsoveeoZHSd7tmOAfsEnOjU58PhPUqXvPURxC', 'author', '', '$2y$10$quickbrownfoxjumpsover');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
